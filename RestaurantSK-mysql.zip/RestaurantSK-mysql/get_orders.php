<?php
include 'connect.php';

try {
    $stmt = $con->prepare("SELECT 
        po.order_id, 
        po.customer_name, 
        po.total_price, 
        po.order_time, 
        po.delivered,
        cp.discount_rate
    FROM placed_orders po
    LEFT JOIN coupon cp ON po.coupon_id = cp.coupon_id
    ORDER BY po.order_time DESC");
    $stmt->execute();
    $orders = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    die("Error: " . $e->getMessage());
}
?>

<table class="table table-bordered table-hover">
    <thead class="thead-dark">
        <tr>
            <th>Order ID</th>
            <th>Customer Name</th>
            <th>Total Price</th>
            <th>Status</th>
            <th>Order Time</th>
        </tr>
    </thead>
    <tbody>
        <?php if (!empty($orders)): ?>
            <?php foreach ($orders as $order): 
                $discountedTotal = $order['total_price'] * (100 - ($order['discount_rate'] ?? 0)) / 100;
                ?>
                <tr>
                    <td><?= htmlspecialchars($order['order_id']) ?></td>
                    <td><?= htmlspecialchars($order['customer_name']) ?></td>
                    <td>$<?= number_format($discountedTotal, 2) ?></td>
                    <td>
                        <span class="status-badge <?= $order['delivered'] ? 'delivered' : 'preparing' ?>">
                            <?= $order['delivered'] ? 'Delivered' : 'Preparing' ?>
                        </span>
                    </td>
                    <td><?= date('M j, Y H:i', strtotime($order['order_time'])) ?></td>
                </tr>
            <?php endforeach; ?>
        <?php else: ?>
            <tr>
                <td colspan="5" class="text-center">No orders found</td>
            </tr>
        <?php endif; ?>
    </tbody>
</table>
