<?php
include '../functions/functions.php';
include '../../connect.php';

if (isset($_POST['contact_name']) && isset($_POST['contact_email']) && isset($_POST['contact_message']) && isset($_POST['rating'])) {
    try {
        $feedback_name = test_input($_POST['contact_name']);
        $feedback_email = test_input($_POST['contact_email']);
        $feedback_message = test_input($_POST['contact_message']);
        $feedback_rating = test_input($_POST['rating']);


        // Validate inputs
        if (empty($feedback_name) || empty($feedback_email) || empty($feedback_message)) {
            throw new Exception('Please fill in all required fields');
        }

        if (!filter_var($feedback_email, FILTER_VALIDATE_EMAIL)) {
            throw new Exception('Please enter a valid email address.');
        }

        // Insert into database
        $stmt = $con->prepare("INSERT INTO feedback(feedback_name, feedback_email, feedback_subject,feedback_rating) VALUES (?, ?, ?,?)");
        $stmt->execute([$feedback_name, $feedback_email, $feedback_message, $feedback_rating]);

        // Return success message
        echo json_encode([
            'status' => 'success',
            'message' => 'Thank you for your feedback! We appreciate your input.'
        ]);
        exit;

    } catch (Exception $e) {
        // Return error message
        echo json_encode([
            'status' => 'error',
            'message' => $e->getMessage()
        ]);
        exit;
    }
}
?>