<!-- PHP INCLUDES -->

<?php
//Set page title
$pageTitle = 'Order Status';

include "connect.php";
include 'Includes/functions/functions.php';
include "Includes/templates/header.php";
include "Includes/templates/navbar.php";


?>

<style type="text/css">
    .check_order_id_submit {
        background: #ffc851;
        color: white;
        border-color: #ffc851;
        font-family: work sans, sans-serif;
    }

    .client_details_tab .form-control {
        background-color: #fff;
        border-radius: 0;
        padding: 25px 10px;
        box-shadow: none;
        border: 2px solid #eee;
    }

    .client_details_tab .form-control:focus {
        border-color: #ffc851;
        box-shadow: none;
        outline: none;
    }

    .text_header {
        margin-bottom: 5px;
        font-size: 18px;
        font-weight: bold;
        line-height: 1.5;
        margin-top: 22px;
        text-transform: capitalize;
    }

    .layer {
        height: 100%;
        background: -moz-linear-gradient(top, rgba(45, 45, 45, 0.4) 0%, rgba(45, 45, 45, 0.9) 100%);
        background: -webkit-linear-gradient(top, rgba(45, 45, 45, 0.4) 0%, rgba(45, 45, 45, 0.9) 100%);
        background: linear-gradient(to bottom, rgba(45, 45, 45, 0.4) 0%, rgba(45, 45, 45, 0.9) 100%);
    }
</style>

<!-- START ORDER STATUS SECTION -->

<section style="
    background: url(Design/images/food_pic_1.jpg);
    background-position: center bottom;
    background-repeat: no-repeat;
    background-size: cover;">
    <div class="layer">
        <div style="text-align: center;padding: 15px;">
            <h1 style="font-size: 80px; color: white;font-family: 'Roboto'; font-weight: 100;
">Order Status</h1>
        </div>
    </div>

</section>

<section class="table_reservation_section">

    <div class="container">
        <?php
        $orderItems = [];
        $errorMessage = null;
        $prefillOrderId = $_GET['order_id'] ?? '';


        if (isset($_POST['check_order_id_submit']) && $_SERVER['REQUEST_METHOD'] === 'POST' || !empty($prefillOrderId)) {
            // Selected Order_ID
        
            $order_id = $_POST['order_id'] ?? $prefillOrderId;


            $con->beginTransaction();
            try {
                $stmt = $con->prepare("SELECT po.order_id,po.order_time,po.delivered,oi.menu_id,oi.quantity,m.menu_name,m.menu_price,cp.coupon_code,cp.discount_rate
                                        FROM placed_orders po
                                        LEFT JOIN in_order oi
                                        ON po.order_id =oi.order_id
                                        LEFT JOIN menu m
                                        ON m.menu_id=oi.menu_id
                                        LEFT JOIN coupon cp
                                        ON po.coupon_id=cp.coupon_id
                                        WHERE oi.order_id = :order_id ORDER BY menu_id");
                $stmt->bindParam(':order_id', $order_id);
                $stmt->execute();

                $orderItems = $stmt->fetchAll(PDO::FETCH_ASSOC);
                $stmtDeliveryStatus = $con->prepare("SELECT order_id,order_time,delivered from placed_orders where order_id= :order_id");
                $stmtDeliveryStatus->bindParam(":order_id", $order_id);
                $stmtDeliveryStatus->execute();
                $deliveryStatus = $stmtDeliveryStatus->fetch(PDO::FETCH_ASSOC);

                if (empty($orderItems)) {
                    $errorMessage = "No items found for Order ID: " . htmlspecialchars($order_id);
                }
            } catch (Exception $e) {
                $errorMessage = "Database error: " . $e->getMessage();
            }
        }


        ?>



        <div class="text_header">
            <span>
                1. Input Order ID
            </span>
        </div>
        <form method="POST" action="order_status.php">
            <div class="row">
                <div class="col-lg-3 col-md-3 col-sm-6 col-xs-6">
                    <div class="form-group">
                        <label for="order_id">Order ID</label>
                        <input type="text" class="form-control" name="order_id"
                            value="<?= htmlspecialchars($prefillOrderId) ?>">
                    </div>
                </div>
                <div class="col-lg-3 col-md-3 col-sm-6 col-xs-6">
                    <div class="form-group">
                        <label for="order_id_submit" style="visibility: hidden;">Order ID Submit</label>
                        <input type="submit" class="form-control check_order_id_submit" name="check_order_id_submit">
                    </div>
                </div>
            </div>
        </form>


        <!-- Test Show Part -->
        <?PHP


        if (empty($orderItems)) {
            ?>

            <?PHP
        } else {
            ?>

            <span>
                2. Order details
            </span>
        </div>
        <div class="oder-result">
            <?php if (!empty($orderItems)): ?>
                <?php if (!empty($deliveryStatus)): ?>
                    <div class="alert alert-info" role="alert">
                        <strong>Delivery Status:</strong>
                        <?= $deliveryStatus['delivered'] == 1 ? "<span class='text-success'>Delivered</span>" : "<span class='text-warning'>Still in process</span>" ?>
                        <br>
                        <strong>Order Time:</strong> <?= htmlspecialchars($deliveryStatus['order_time']) ?>
                    </div>
                <?php endif; ?>
                <h3>Order #<?= htmlspecialchars($order_id) ?> Details:</h3>

                <table class="table table-bordered">
                    <thead>
                        <tr>
                            <th>Menu ID</th>
                            <th>Item Name</th>
                            <th>Quantity</th>
                            <th>Price Each</th>
                            <th>Total</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        $grandTotal = 0;

                        foreach ($orderItems as $item):
                            $lineTotal = $item['menu_price'] * $item['quantity'];
                            $grandTotal += $lineTotal;

                            ?>
                            <tr>
                                <td><?= htmlspecialchars($item['menu_id']) ?></td>
                                <td><?= htmlspecialchars($item['menu_name']) ?></td>
                                <td><?= htmlspecialchars($item['quantity']) ?></td>
                                <td>$<?= number_format($item['menu_price'], 2) ?></td>
                                <td>$<?= number_format($lineTotal, 2) ?></td>
                            </tr>
                        <?php endforeach; ?>
                        <td colspan="4" class="text-right"><strong>Coupon Discount Rate</strong></td>
                        <td><strong><?php echo $item['coupon_code'] != null ? $item['discount_rate'] . '%' : "-"; ?></strong>
                        </td>
                        <?php
                        $discount_rate = $item['coupon_code'] != null ? $item['discount_rate'] : 0;
                        $grandTotal = $grandTotal * (100 - $discount_rate) / 100;
                        ?>
                        <tr>
                            <td colspan="4" class="text-right"><strong>Grand Total</strong></td>
                            <td><strong>$<?= number_format($grandTotal, 2) ?></strong></td>
                        </tr>
                    </tbody>
                </table>
                
            <?php elseif ($errorMessage): ?>
                <div class="alert alert-danger">
                    <?= $errorMessage ?>
                </div>
            <?php endif; ?>
        </div>
        <?PHP
        }

        ?>





    </div>
</section>

<style type="text/css">
    .details_card {
        display: flex;
        align-items: center;
        margin: 150px 0px;
    }

    .details_card>span {
        float: left;
        font-size: 60px;
    }

    .details_card>div {
        float: left;
        font-size: 20px;
        margin-left: 20px;
        letter-spacing: 2px
    }

 
</style>



<!-- FOOTER BOTTOM  -->

<?php include "Includes/templates/footer.php"; ?>

