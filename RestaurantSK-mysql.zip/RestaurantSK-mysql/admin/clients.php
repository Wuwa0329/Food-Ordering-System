<?php
ob_start();
session_start();

$pageTitle = 'Clients';

if (!isset($_SESSION['username']) || !isset($_SESSION['role'])) {
    header("Location: ../index.php");
    exit;
}

$currentFile = basename($_SERVER['PHP_SELF']);

if ($_SESSION['role'] === 'staff' && $currentFile !== 'dashboard.php') {

    echo "<!DOCTYPE html>
    <html>
    <head>
        <title>Unauthorized</title>
        <meta charset='UTF-8'>
        <style>
            body {
                font-family: Arial, sans-serif;
                padding: 40px;
                background-color: #f8d7da;
                color: #721c24;
                text-align: center;
            }
            .alert {
                border: 1px solid #f5c6cb;
                padding: 20px;
                border-radius: 10px;
                display: inline-block;
                background-color: #f8d7da;
            }
            .countdown {
                font-weight: bold;
                font-size: 20px;
            }
        </style>
        <script>
            let seconds = 5;
            function updateCountdown() {
                const countdownEl = document.getElementById('countdown');
                countdownEl.innerText = seconds;
                if (seconds === 0) {
                    window.location.href = 'dashboard.php';
                } else {
                    seconds--;
                    setTimeout(updateCountdown, 1000);
                }
            }
            window.onload = updateCountdown;
        </script>
    </head>
    <body>
        <div class='alert'>
            <h2>Unauthorized Access</h2>
            <p>Staff users are not allowed to view this page.</p>
            <p>Redirecting back dashboard in <span class='countdown' id='countdown'>5</span> seconds...</p>
        </div>
    </body>
    </html>";
    exit;
}
include 'connect.php';
include 'Includes/functions/functions.php';
include 'Includes/templates/header.php';
include 'Includes/templates/navbar.php';

?>

<script type="text/javascript">

    var vertical_menu = document.getElementById("vertical-menu");


    var current = vertical_menu.getElementsByClassName("active_link");

    if (current.length > 0) {
        current[0].classList.remove("active_link");
    }

    vertical_menu.getElementsByClassName('clients_link')[0].className += " active_link";

</script>

<?php


$do = 'Manage';

if ($do == "Manage") {
    $stmt = $con->prepare("SELECT * FROM clients");
    $stmt->execute();
    $clients = $stmt->fetchAll();

    ?>
    <div class="card">
        <div class="card-header">
            <?php echo $pageTitle; ?>
        </div>
        <div class="card-body">

            <!-- CLIENTS TABLE -->

            <table class="table table-bordered clients-table">
                <thead>
                    <tr>
                        <th scope="col">Client Name</th>
                        <th scope="col">Phone number</th>
                        <th scope="col">E-mail</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                    foreach ($clients as $client) {
                        echo "<tr>";
                        echo "<td>";
                        echo $client['client_name'];
                        echo "</td>";
                        echo "<td>";
                        echo $client['client_phone'];
                        echo "</td>";
                        echo "<td>";
                        echo $client['client_email'];
                        echo "</td>";
                        echo "</tr>";
                    }
                    ?>
                </tbody>
            </table>
        </div>
    </div>
    <?php
}


/* FOOTER BOTTOM */

include 'Includes/templates/footer.php';


?>