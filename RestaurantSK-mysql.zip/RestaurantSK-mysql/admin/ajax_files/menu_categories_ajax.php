<?php include '../connect.php'; ?>
<?php include '../Includes/functions/functions.php'; ?>


<?php
	
	if(isset($_POST['do']) && $_POST['do'] == "Add")
	{
        $category_name = test_input($_POST['category_name']);

        $checkItem = checkItem("category_name","menu_categories",$category_name);

        if($checkItem != 0)
        {
            $data['alert'] = "Warning";
            $data['message'] = "This category name already exists!";
            echo json_encode($data);
            exit();
        }
        elseif($checkItem == 0)
        {
        	//Insert into the database
            $stmt = $con->prepare("insert into menu_categories(category_name) values(?) ");
            $stmt->execute(array($category_name));

            $data['alert'] = "Success";
            $data['message'] = "The new category has been inserted successfully !";
            echo json_encode($data);
            exit();
        }
            
	}

	if(isset($_POST['do']) && $_POST['do'] == "Delete")
	{
		$category_id = $_POST['category_id'];

        $stmt = $con->prepare("UPDATE  menu_categories set DELETED = 1 where category_id = ?");
        $stmt->execute(array($category_id));    
	}

    if(isset($_POST['do']) && $_POST['do'] == "Edit")
    {
        $category_id = $_POST['category_id']; // You need to get the ID of the category to edit
        $new_category_name = test_input($_POST['category_name']); // Get and sanitize the new name
    
        // First check if the name is actually being changed
        $stmt = $con->prepare("SELECT category_name FROM menu_categories WHERE category_id = ?");
        $stmt->execute(array($category_id));
        $current_category = $stmt->fetch();
    
        if($current_category['category_name'] == $new_category_name) {
            $data['alert'] = "Warning";
            $data['message'] = "No changes were made - the name is the same.";
            echo json_encode($data);
            exit();
        }
    
        // Check if the new name already exists in other categories
        $stmt = $con->prepare("SELECT COUNT(*) FROM menu_categories WHERE category_name = ? AND category_id != ?");
        $stmt->execute(array($new_category_name, $category_id));
        $count = $stmt->fetchColumn();
    
        if($count > 0) {
            $data['alert'] = "Warning";
            $data['message'] = "This category name already exists!";
            echo json_encode($data);
            exit();
        }
    
        // Update the category
        $stmt = $con->prepare("UPDATE menu_categories SET category_name = ? WHERE category_id = ?");
        $stmt->execute(array($new_category_name, $category_id));
    
        $data['alert'] = "Success";
        $data['message'] = "Category has been updated successfully!";
        echo json_encode($data);
        exit();
    }
	
?>