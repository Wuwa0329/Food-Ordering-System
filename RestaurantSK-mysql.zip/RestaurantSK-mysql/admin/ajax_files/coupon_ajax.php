<?php include '../connect.php'; ?>
<?php include '../Includes/functions/functions.php'; ?>


<?php
header('Content-Type: application/json');
$action = $_POST['action'] ?? '';

if ($action === 'add_coupon') {
    $code = trim($_POST['code'] ?? '');
    $discount = $_POST['discount'] ?? '';

    if (!$code || strlen($code) > 10) {
        echo json_encode(['success' => false, 'error' => 'Coupon code must be 10 characters or less.']);
    } elseif (!ctype_digit($discount)) {
        echo json_encode(['success' => false, 'error' => 'Discount must be an integer.']);
    } else {
        try {
            $stmt = $con->prepare("INSERT INTO coupon (coupon_code, discount_rate, status) VALUES (?, ?, 1)");
            $stmt->execute([$code, (int) $discount]);
            echo json_encode(['success' => true]);
        } catch (PDOException $e) {
            echo json_encode(['success' => false, 'error' => 'DB Error: ' . $e->getMessage()]);
        }
    }
    exit;
}

if ($action === 'toggle_status') {
    $id = $_POST['id'] ?? null;
    if ($id && is_numeric($id)) {
        $stmt = $con->prepare("UPDATE coupon SET status = 0 WHERE coupon_id = ?");
        $stmt->execute([$id]);
        echo json_encode(['success' => true]);
    } else {
        echo json_encode(['success' => false, 'error' => 'Invalid ID']);
    }
    exit;
}

if ($action === 'fetch_coupons') {
    $stmt = $con->query("SELECT * FROM coupon ORDER BY coupon_id ASC");
    $coupons = $stmt->fetchAll(PDO::FETCH_ASSOC);
    foreach ($coupons as &$c) {
        $c['status_label'] = $c['status'] ? 'valid' : 'invalid';
    }

    echo json_encode(['success' => true, 'data' => $coupons]);
    exit;
}

?>