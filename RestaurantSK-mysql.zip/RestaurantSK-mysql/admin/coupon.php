<?php
ob_start();
session_start();

$pageTitle = 'Coupon'; // Change as needed

if (!isset($_SESSION['username']) || !isset($_SESSION['role'])) {
    header("Location: ../index.php");
    exit;
}

$currentFile = basename($_SERVER['PHP_SELF']);

if ($_SESSION['role'] === 'staff' && $currentFile !== 'dashboard.php') {

    echo "<!DOCTYPE html>
    <html>
    <head>
        <title>Unauthorized</title>
        <meta charset='UTF-8'>
        <style>
            body {
                font-family: Arial, sans-serif;
                padding: 40px;
                background-color: #f8d7da;
                color: #721c24;
                text-align: center;
            }
            .alert {
                border: 1px solid #f5c6cb;
                padding: 20px;
                border-radius: 10px;
                display: inline-block;
                background-color: #f8d7da;
            }
            .countdown {
                font-weight: bold;
                font-size: 20px;
            }
        </style>
        <script>
            let seconds = 5;
            function updateCountdown() {
                const countdownEl = document.getElementById('countdown');
                countdownEl.innerText = seconds;
                if (seconds === 0) {
                    window.location.href = 'dashboard.php';
                } else {
                    seconds--;
                    setTimeout(updateCountdown, 1000);
                }
            }
            window.onload = updateCountdown;
        </script>
    </head>
    <body>
        <div class='alert'>
            <h2>Unauthorized Access</h2>
            <p>Staff users are not allowed to view this page.</p>
            <p>Redirecting back dashboard in <span class='countdown' id='countdown'>5</span> seconds...</p>
        </div>
    </body>
    </html>";
    exit;
}

include 'connect.php';
include 'Includes/functions/functions.php';
include 'Includes/templates/header.php';
include 'Includes/templates/navbar.php';
?>


<script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>

<script type="text/javascript">

    var vertical_menu = document.getElementById("vertical-menu");


    var current = vertical_menu.getElementsByClassName("active_link");

    if (current.length > 0) {
        current[0].classList.remove("active_link");
    }

    vertical_menu.getElementsByClassName('coupon_link')[0].className += " active_link";

</script>

<style type="text/css">
    .coupon-table td,
    .coupon-table th {
        vertical-align: middle;
        text-align: center;
    }
</style>

<div class="card">
    <div class="card-header">
        <?php echo $pageTitle; ?>
    </div>
    <div class="card-body">

        <!-- ADD NEW COUPON BUTTON -->

        <button class="btn btn-success btn-sm" style="margin-bottom: 10px;" type="button" data-toggle="modal"
            data-target="#add_new_coupon" data-placement="top">
            <i class="fa fa-plus"></i>
            Add Coupon
        </button>

        <!-- Add New Coupon Modal -->

        <!-- Add Coupon Modal -->
        <div class="modal fade" id="add_new_coupon" tabindex="-1" role="dialog" aria-hidden="true">
            <div class="modal-dialog" role="document">
                <div class="modal-content">

                    <div class="modal-header">
                        <h5 class="modal-title">Add New Coupon</h5>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>

                    <div class="modal-body">
                        <div id="add_coupon_result" class="mb-2"></div>

                        <!-- Coupon Code -->
                        <div class="form-group">
                            <label for="coupon_code_input">Coupon Code</label>
                            <input type="text" id="coupon_code_input" class="form-control" placeholder="Coupon Code"
                                name="Coupon_code">
                        </div>

                        <!-- Discount Rate -->
                        <div class="form-group">
                            <label for="discount_rate_input">Discount Rate (%)</label>
                            <input type="text" id="discount_rate_input" class="form-control" placeholder="Discount Rate"
                                onkeyup="this.value=this.value.replace(/[^0-9]/g,'');" name="Discount_rate">
                        </div>
                    </div>

                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancel</button>
                        <button type="button" class="btn btn-info" id="add_coupon_bttn">Add Coupon</button>
                    </div>

                </div>
            </div>
        </div>



        <!-- Coupon TABLE -->

        <table class="table table-bordered gallery-table" id="coupon_table">
            <thead>
                <tr>
                    <th scope="col">Coupon ID</th>
                    <th scope="col">Coupon Code</th>
                    <th scope="col">Discount Rate (%)</th>
                    <th scope="col">Manage</th>
                </tr>
            </thead>
            <tbody>
                <!--Filled by JS-->
            </tbody>
        </table>
    </div>
</div>

<!--Modal for confirmInvalidate coupon-->
<div class="modal fade" id="confirmToggleModal" tabindex="-1" role="dialog" aria-labelledby="confirmToggleModalLabel"
    aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header bg-warning">
                <h5 class="modal-title" id="confirmToggleModalLabel">Confirm Status Change</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                Are you sure you want to <strong>invalidate</strong> this coupon?
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancel</button>
                <button type="button" id="confirmToggleBtn" class="btn btn-danger delete_category_bttn">Yes,
                    Invalidate</button>
            </div>
        </div>
    </div>
</div>
<?php

/*** FOOTER BOTTON ***/

include 'Includes/templates/footer.php';

?>


<script type="text/javascript">

    //Fetch list of coupon

    function fetchCoupons() {
        const formData = new FormData();
        formData.append('action', 'fetch_coupons');

        fetch('ajax_files/coupon_ajax.php', {
            method: 'POST',
            body: formData
        }).then(res => res.json()).then(data => {
            if (data.success) {
                const tbody = document.querySelector('#coupon_table tbody');
                tbody.innerHTML = '';
                data.data.forEach(coupon => {
                    const row = document.createElement('tr');
                    row.innerHTML = `
                    <td>${coupon.coupon_id}</td>
                    <td>${coupon.coupon_code}</td>
                    <td>${coupon.discount_rate}</td>
                    <td>
                        ${coupon.status_label}
                        ${coupon.status == 1 ? `<button class="btn btn-sm btn-warning ml-2" onclick="confirmToggle(${coupon.coupon_id}, ${coupon.status})">Toggle</button>` : ''}
                    </td>
                `;
                    tbody.appendChild(row);
                });
            }
        });
    }
    //confirm toggle
    let toggleTargetId = null;

    function confirmToggle(id, currentStatus) {
        if (currentStatus == 1) {
            // If currently valid, show modal before invalidating
            toggleTargetId = id;
            $('#confirmToggleModal').modal('show');
        } else {
            // If currently invalid, toggle immediately
            toggleStatus(id);
        }
    }

    document.getElementById('confirmToggleBtn').addEventListener('click', function () {
        if (toggleTargetId !== null) {
            toggleStatus(toggleTargetId);
            $('#confirmToggleModal').modal('hide');
            toggleTargetId = null;
        }
    });

    //toggle coupon status
    function toggleStatus(id) {
        const formData = new FormData();
        formData.append('action', 'toggle_status');
        formData.append('id', id);

        fetch('ajax_files/coupon_ajax.php', {
            method: 'POST',
            body: formData
        }).then(res => res.json()).then(data => {
            if (data.success) fetchCoupons();
        });

    }

    //Button click submit

    document.getElementById('add_coupon_bttn').addEventListener('click', function () {
        const codeInput = document.getElementById('coupon_code_input');
        const discountInput = document.getElementById('discount_rate_input');
        const resultDiv = document.getElementById('add_coupon_result');

        const code = codeInput.value.trim();
        const discount = discountInput.value.trim();

        // Reset feedback
        codeInput.classList.remove('is-invalid');
        discountInput.classList.remove('is-invalid');
        resultDiv.innerHTML = '';

        let errorMessages = [];

        // Validation logic
        if (!code) {
            errorMessages.push("Coupon code is required.");
            codeInput.classList.add('is-invalid');
        } else if (code.length > 10) {
            errorMessages.push("Coupon code must not be more than 10 characters.");
            codeInput.classList.add('is-invalid');
        }

        if (!discount) {
            errorMessages.push("Discount rate is required.");
            discountInput.classList.add('is-invalid');
        } else if (!/^\d+$/.test(discount)) {
            errorMessages.push("Discount rate must be a numeric integer.");
            discountInput.classList.add('is-invalid');
        } else if (parseInt(discount) >= 20) {
            errorMessages.push("Discount rate must be less than 20.");
            discountInput.classList.add('is-invalid');
        }

        if (errorMessages.length > 0) {
            resultDiv.innerHTML = `
            <div class="alert alert-danger" role="alert">
                <ul style="margin-bottom:0;">
                    ${errorMessages.map(msg => `<li>${msg}</li>`).join('')}
                </ul>
            </div>
        `;
            return;
        }

        // Send to PHP via AJAX
        const formData = new FormData();
        formData.append('action', 'add_coupon');
        formData.append('code', code);
        formData.append('discount', discount);

        fetch('ajax_files/coupon_ajax.php', {
            method: 'POST',
            body: formData
        })
            .then(res => res.json())
            .then(data => {
                if (data.success) {
                    $('#add_new_coupon').modal('hide');
                    codeInput.value = '';
                    discountInput.value = '';
                    resultDiv.innerHTML = '';
                    fetchCoupons(); // call your refresh function
                } else {
                    resultDiv.innerHTML = `
                <div class="alert alert-danger" role="alert">
                    ${data.error || 'Something went wrong.'}
                </div>
            `;
                }
            })
            .catch(() => {
                resultDiv.innerHTML = `
            <div class="alert alert-danger" role="alert">
                An unexpected error occurred.
            </div>
        `;
            });
    });


    window.onload = fetchCoupons;


</script>