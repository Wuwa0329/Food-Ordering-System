<!-- PHP INCLUDES -->

<?php
//Set page title
$pageTitle = 'Order Food';

include "connect.php";
include 'Includes/functions/functions.php';
include "Includes/templates/header.php";
include "Includes/templates/navbar.php";


?>

<!-- ORDER FOOD PAGE STYLE -->

<style type="text/css">
    body {
        background: #f7f7f7;
    }

    .text_header {
        margin-bottom: 5px;
        font-size: 18px;
        font-weight: bold;
        line-height: 1.5;
        margin-top: 22px;
        text-transform: capitalize;
    }

    .items_tab {
        border-radius: 4px;
        background-color: white;
        overflow: hidden;
        box-shadow: 0 0 5px 0 rgba(60, 66, 87, 0.04), 0 0 10px 0 rgba(0, 0, 0, 0.04);
    }

    .itemListElement {
        font-size: 14px;
        line-height: 1.29;
        border-bottom: solid 1px #e5e5e5;
        cursor: pointer;
        padding: 16px 12px 18px 12px;
    }

    .item_details {
        width: auto;
        display: -webkit-box;
        display: -moz-box;
        display: -ms-flexbox;
        display: -webkit-flex;
        display: flex;
        flex-direction: row;
        justify-content: space-between;
        align-items: center;
        -webkit-box-orient: horizontal;
        -webkit-box-direction: normal;
        -webkit-flex-direction: row;
        -webkit-box-pack: justify;
        -webkit-justify-content: space-between;
        -webkit-box-align: center;
        -webkit-align-items: center;
    }

    .item_label {
        color: #9e8a78;
        border-color: #9e8a78;
        background: white;
        font-size: 12px;
        font-weight: 700;
    }

    .btn-secondary:not(:disabled):not(.disabled).active,
    .btn-secondary:not(:disabled):not(.disabled):active {
        color: #fff;
        background-color: #9e8a78;
        border-color: #9e8a78;
    }

    .item_select_part {
        display: flex;
        -webkit-box-pack: justify;
        justify-content: space-between;
        -webkit-box-align: center;
        align-items: center;
        flex-shrink: 0;
    }

    .select_item_bttn {
        width: 55px;
        display: flex;
        margin-left: 30px;
        -webkit-box-pack: end;
        justify-content: flex-end;
    }

    .menu_price_field {
        width: auto;
        display: flex;
        margin-left: 30px;
        -webkit-box-align: baseline;
        align-items: baseline;
    }

    .order_food_section {
        max-width: 720px;
        margin: 50px auto;
        padding: 0px 15px;
    }

    .item_label.focus,
    .item_label:focus {
        outline: none;
        background: initial;
        box-shadow: none;
        color: #9e8a78;
        border-color: #9e8a78;
    }

    .item_label:hover {
        color: #fff;
        background-color: #9e8a78;
        border-color: #9e8a78;
    }

    /* Make circles that indicate the steps of the form: */
    .step {
        height: 15px;
        width: 15px;
        margin: 0 2px;
        background-color: #bbbbbb;
        border: none;
        border-radius: 50%;
        display: inline-block;
        opacity: 0.5;
    }

    .step.active {
        opacity: 1;
    }

    /* Mark the steps that are finished and valid: */
    .step.finish {
        background-color: #4CAF50;
    }


    .order_food_tab {
        display: none;
    }

    .next_prev_buttons {
        background-color: #4CAF50;
        color: #ffffff;
        border: none;
        padding: 10px 20px;
        font-size: 17px;
        cursor: pointer;
    }

    .client_details_tab .form-control {
        background-color: #fff;
        border-radius: 0;
        padding: 25px 10px;
        box-shadow: none;
        border: 2px solid #eee;
    }

    .client_details_tab .form-control:focus {
        border-color: #ffc851;
        box-shadow: none;
        outline: none;
    }

    .quantity-controls {
        display: inline-block;
        border-radius: 5px;
        overflow: hidden;
    }

    .quantity-button {
        background-color: #f0f0f0;
        border: none;
        color: #333;
        padding: 5px 10px;
        text-align: center;
        text-decoration: none;
        display: inline-block;
        font-size: 16px;
        cursor: pointer;
        -webkit-user-select: none;
        -moz-user-select: none;
        -ms-user-select: none;
        user-select: none;
    }

    .quantity-display {
        width: 40px;
        padding: 5px;
        text-align: center;
        border: none;
        font-size: 16px;
        background-color: #eee;
    }

    input::-webkit-outer-spin-button,
    input::-webkit-inner-spin-button {
        -webkit-appearance: none;
        margin: 0;
    }

    input[type=number] {
        -moz-appearance: textfield;
    }
</style>

<!-- START ORDER FOOD SECTION -->

<section class="order_food_section">

    <?php
    if (isset($_POST['submit_order_food_form']) && $_SERVER['REQUEST_METHOD'] === 'POST') {
        // Client Details
        $client_full_name = test_input($_POST['client_full_name']);
        $delivery_address = test_input($_POST['client_delivery_address']);
        $client_phone_number = test_input($_POST['client_phone_number']);
        $client_email = test_input($_POST['client_email']);
        $client_coupon = test_input($_POST['client_coupon']);
        $coupon_id = null;
        // Menu items
        $menu_quantities = $_POST['items'] ?? [];

        // Debugging: Log received data
        error_log("Client: $client_full_name, Items: " . print_r($menu_quantities, true));

        $con->beginTransaction();
        try {
            // 1. Insert Client
            $stmtExistingClient = $con->prepare("SELECT client_id FROM clients WHERE client_name=? AND client_phone=? AND client_email=?");
            $stmtExistingClient->execute([$client_full_name, $client_phone_number, $client_email]);
            $client_id = $stmtExistingClient->fetchColumn();

            if (empty($client_id)) {
                $stmtClient = $con->prepare("INSERT INTO clients(client_name, client_phone, client_email) VALUES(?,?,?)");
                if (!$stmtClient->execute([$client_full_name, $client_phone_number, $client_email])) {
                    throw new Exception("Failed to insert client");
                }
                $client_id = $con->lastInsertId();
                error_log("Client ID: $client_id");
            }

            // 2. Create Order
            if (!empty($client_coupon)) {
                $stmtCoupon = $con->prepare("SELECT coupon_id FROM coupon WHERE coupon_code=? AND status=1");
                $stmtCoupon->execute([$client_coupon]);
                $coupon_id = $stmtCoupon->fetchColumn();

                if (!$coupon_id) {
                    throw new Exception("Invalid or inactive coupon code:$client_coupon");
                }
            }
            $stmtOrder = $con->prepare("INSERT INTO placed_orders(order_time, client_id, delivery_address,coupon_id) VALUES(?, ?, ?,?)");
            $order_time = date("Y-m-d H:i:s");
            if (!$stmtOrder->execute([$order_time, $client_id, $delivery_address, $coupon_id])) {
                throw new Exception("Failed to create order");
            }
            $order_id = $con->lastInsertId();
            error_log("Order ID: $order_id");

            // 3. Process Menu Items
            $hasItems = false;
            $menutmt = $con->prepare("SELECT menu_id FROM menu WHERE LOWER(REPLACE(menu_name, ' ', '_')) = ?");

            foreach ($menu_quantities as $menu_key => $quantity) {
                $quantity = (int) $quantity;
                if ($quantity > 0) {
                    $menutmt->execute([$menu_key]);
                    $menu_id = $menutmt->fetchColumn();

                    if ($menu_id) {
                        $stmtItem = $con->prepare("INSERT INTO in_order(order_id, menu_id, quantity) VALUES(?, ?, ?)");
                        if (!$stmtItem->execute([$order_id, $menu_id, $quantity])) {
                            throw new Exception("Failed to insert menu item $menu_id");
                        }
                        $hasItems = true;
                        error_log("Inserted: $menu_id x $quantity");
                    }
                }
            }

            if (!$hasItems) {
                throw new Exception("No valid items with quantity > 0");
            }

            $con->commit();
            echo "<script>
    alert('Order created successfully! Order #$order_id');
    window.location.href = 'order_status.php?order_id=$order_id';
</script>";
            exit;

        } catch (Exception $e) {
            $con->rollBack();
            error_log("Transaction failed: " . $e->getMessage());
            echo "<div class='alert alert-danger'>Error: " . htmlspecialchars($e->getMessage()) . "</div>";
        }
    }
    ?>

    <!-- ORDER FOOD FORM -->

    <form method="post" id="order_food_form" action="order_food.php">

        <!-- SELECT MENU -->

        <div class="select_menu_tab order_food_tab" id="menu_tab">

            <!-- ALERT MESSAGE -->

            <div class="alert alert-danger" role="alert" style="display: none">
                Please, select at least one item!
            </div>

            <div class="text_header">
                <span>
                    1. Choice of Items
                </span>
            </div>

            <div>
                <?php
                $stmt = $con->prepare("Select * from menu_categories where DELETED = 0");
                $stmt->execute();
                $menu_categories = $stmt->fetchAll();


                foreach ($menu_categories as $category) {
                    ?>
                    <div class="text_header">
                        <span>
                            <?php echo $category['category_name']; ?>
                        </span>
                    </div>
                    <div class="items_tab">
                        <?php
                        $stmt = $con->prepare("Select * from menu where category_id = ? AND DELETED = 0");
                        $stmt->execute(array($category['category_id']));
                        $rows = $stmt->fetchAll();

                        foreach ($rows as $row) {
                            $quantityInputID = "qty_" . strtolower(str_replace(' ', '_', $row['menu_name']));
                            $quantityInputName = "items[" . strtolower(str_replace(' ', '_', $row['menu_name'])) . "]";
                            echo "<div class='itemListElement'>";
                            echo "<div class = 'item_details'>";
                            echo "<div>";
                            echo $row['menu_name'];
                            echo "</div>";
                            echo "<div class = 'item_select_part'>";
                            echo "<div class = 'menu_price_field'>";
                            echo "<span style = 'font-weight: bold;'>";
                            echo $row['menu_price'] . "$";
                            echo "</span>";
                            echo "</div>";
                            ?>
                            <?php
                            echo '<div class="quantity-controls">';
                            echo '<button type="button" class="quantity-button" onclick="decreaseQuantity(\'' . $quantityInputID . '\')">-</button>';
                            echo '<input type="number" id="' . $quantityInputID . '" name="' . $quantityInputName . '" value="0" min="0" class="quantity-input" readonly>';
                            echo '<button type="button" class="quantity-button" onclick="increaseQuantity(\'' . $quantityInputID . '\')">+</button>';
                            echo '</div>';

                            ?>
                            <?php
                            echo "</div>";
                            echo "</div>";
                            echo "</div>";
                        }
                        ?>
                    </div>
                    <?php
                }
                ?>
            </div>
        </div>


        <!-- CLIENT DETAILS -->


        <div class="client_details_tab order_food_tab" id="clients_tab">

            <div class="text_header">
                <span>
                    2. Client Details
                </span>
            </div>

            <div>
                <div class="form-group colum-row row">
                    <div class="col-sm-12">
                        <input type="text" name="client_full_name" id="client_full_name"
                            oninput="document.getElementById('required_fname').style.display = 'none'"
                            onkeyup="this.value=this.value.replace(/[^\sa-zA-Z]/g,'');" class="form-control"
                            placeholder="Full name">
                        <div class="invalid-feedback" id="required_fname">
                            Invalid Name!
                        </div>
                    </div>
                </div>
                <div class="form-group row">
                    <div class="col-sm-6">
                        <input type="email" name="client_email" id="client_email"
                            oninput="document.getElementById('required_email').style.display = 'none'"
                            class="form-control" placeholder="E-mail">
                        <div class="invalid-feedback" id="required_email">
                            Invalid E-mail!
                        </div>
                    </div>
                    <div class="col-sm-6">
                        <input type="text" name="client_phone_number" id="client_phone_number"
                            oninput="document.getElementById('required_phone').style.display = 'none'"
                            class="form-control" onkeyup="this.value=this.value.replace(/[^0-9]/g,'');"
                            placeholder="Phone number">
                        <div class="invalid-feedback" id="required_phone">
                            Invalid Phone number!
                        </div>
                    </div>
                </div>
                <div class="form-group colum-row row">
                    <div class="col-sm-12">
                        <input type="text" name="client_delivery_address" id="client_delivery_address"
                            oninput="document.getElementById('required_delivery_address').style.display = 'none'"
                            class="form-control" placeholder="Delivery Address">
                        <div class="invalid-feedback" id="required_delivery_address">
                            Invalid Delivery Address!
                        </div>
                    </div>
                </div>
                <div class="form-group colum-row row">
                    <div class="col-sm-12">
                        <input type="text" name="client_coupon" id="client_coupon" class="form-control"
                            placeholder="Coupon">
                        <div class="invalid-feedback">Coupon must be alphanumeric an max 10 characters.</div>
                    </div>
                </div>
            </div>
        </div>

        <!-- NEXT AND PREVIOUS BUTTONS -->

        <div style="overflow:auto;padding: 30px;">
            <div style="float:right;">
                <input type="hidden" name="submit_order_food_form">
                <button type="button" class="next_prev_buttons" style="background-color: #bbbbbb;" id="prevBtn"
                    onclick="nextPrev(-1)">Previous</button>
                <button type="button" id="nextBtn" class="next_prev_buttons" onclick="nextPrev(1)">Next</button>
            </div>
        </div>

        <!-- Circles which indicates the steps of the form: -->

        <div style="text-align:center;margin-top:40px;">
            <span class="step"></span>
            <span class="step"></span>
        </div>

    </form>
</section>





<!-- WIDGET SECTION / FOOTER -->

<section class="widget_section" style="background-color: #222227;padding: 100px 0;">
    <div class="container">
        <div class="row">
            <div class="col-lg-3 col-md-6">
                <div class="footer_widget">
                    <img src="Design/images/restaurant-logo.png" alt="Restaurant Logo"
                        style="width: 150px;margin-bottom: 20px;">
                    <p>
                        Our Restaurnt is one of the bests, provide tasty Menu and Dishes.
                    </p>
                    
                </div>
            </div>
            <div class="col-lg-3 col-md-6">
                <div class="footer_widget">
                    <h3>Address</h3>
                    <p>
                    22, Level 3, Eco Gallery, Eco Botanic
                    </p>
                    <p>
                        ecobotanic.cafe@gmail.com
                        <br>
                        018-9986545  
                    </p>
                </div>
            </div>
            <div class="col-lg-3 col-md-6">
                <div class="footer_widget">
                    <h3>
                        Opening Hours
                    </h3>
                    <ul class="opening_time">
                        <li>Monday - Friday 10.00am - 9:00pm</li>
                    </ul>
                </div>
            </div>
            
        </div>
    </div>
</section>

<!-- FOOTER BOTTOM  -->

<?php include "Includes/templates/footer.php"; ?>


<!-- JS SCRIPTS -->

<script type="text/javascript">

    /* TOGGLE MENU SELECT BUTTON */

    $('.menu_label').click(function () {
        $(this).button('toggle');

    });

</script>

<!-- JS SCRIPT FOR NEXT AND BACK TABS -->

<script type="text/javascript">

    var currentTab = 0;
    showTab(currentTab);

    //Show Tab Function

    function showTab(n) {
        var x = document.getElementsByClassName("order_food_tab");
        x[n].style.display = "block";

        if (n == 0) {
            document.getElementById("prevBtn").style.display = "none";
        }
        else {
            document.getElementById("prevBtn").style.display = "inline";
        }

        if (n == (x.length - 1)) {
            document.getElementById("nextBtn").innerHTML = "Submit";
        }
        else {
            document.getElementById("nextBtn").innerHTML = "Next";
        }

        fixStepIndicator(n)
    }

    // Next Prev Function

    function nextPrev(n) {
        var x = document.getElementsByClassName("order_food_tab");

        if (n == 1 && !validateForm()) return false;
        // Hide the current tab:
        x[currentTab].style.display = "none";
        // Increase or decrease the current tab by 1:
        currentTab = currentTab + n;
        // if you have reached the end of the form...
        if (currentTab >= x.length) {
            // ... the form gets submitted:
            document.getElementById("order_food_form").submit();
            return false;
        }

        // Otherwise, display the correct tab:
        showTab(currentTab);
    }

    // Validate Form Function

    function validateForm() {
        var x, id_tab, valid = true;
        x = document.getElementsByClassName("order_food_tab");
        id_tab = x[currentTab].id;

        if (id_tab == "menu_tab") {
            var quantityInputs = x[currentTab].querySelectorAll('input[type="number"].quantity-input');
            var hasQuantity = false;


            quantityInputs.forEach(function (input) {
                if (parseInt(input.value) > 0) {
                    hasQuantity = true;
                }
            });

            if (!hasQuantity) {
                x[currentTab].getElementsByClassName("alert")[0].style.display = "block";
                valid = false;
            }
            else {
                x[currentTab].getElementsByClassName("alert")[0].style.display = "none";
            }
        }

        if (id_tab == "clients_tab") {
            y = x[currentTab].getElementsByTagName("input");
            z = x[currentTab].getElementsByClassName("invalid-feedback");

            for (var i = 0; i < y.length; i++) {
                let input = y[i];
                let feedback = z[i];

                if (input.id === "client_coupon") continue;

                if (input.value.trim() === "") {
                    feedback.style.display = "block";
                    valid = false;
                } else if (input.type === "email" && !ValidateEmail(input.value)) {
                    feedback.style.display = "block";
                    valid = false;
                } else {
                    feedback.style.display = "none";
                }
            }

            const couponInput = document.getElementById("client_coupon");
            const couponFeedback = couponInput.nextElementSibling;
            if (couponInput && couponInput.value.trim() !== "") {
                const val = couponInput.value.trim();
                const isValidCoupon = /^[a-zA-Z0-9]{1,10}$/.test(val);
                if (!isValidCoupon) {
                    couponFeedback.style.display = "block";
                    valid = false;
                } else {
                    couponFeedback.style.feedback = "none";
                }
            }
        }

        if (valid) {
            document.getElementsByClassName("step")[currentTab].className += " finish";
        }

        return valid;
    }



    function fixStepIndicator(n) {
        // This function removes the "active" class of all steps...
        var i, x = document.getElementsByClassName("step");

        for (i = 0; i < x.length; i++) {
            x[i].className = x[i].className.replace(" active", "");
        }

        //... and adds the "active" class on the current step:
        x[n].className += " active";
    }


</script>
<!-- JS SCRIPT FOR QUANTITY +- button -->
<script>
    function increaseQuantity(inputID) {
        var input = document.getElementById(inputID);
        input.value = parseInt(input.value) + 1;
    }

    function decreaseQuantity(inputID) {
        var input = document.getElementById(inputID);
        var currentValue = parseInt(input.value);
        if (currentValue > 0) {
            input.value = currentValue - 1;
        }

    }


</script>