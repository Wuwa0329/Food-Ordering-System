<!-- PHP INCLUDES -->

<?php

include "connect.php";
include 'Includes/functions/functions.php';
include "Includes/templates/header.php";
include "Includes/templates/navbar.php";

$stmt_web_settings = $con->prepare("SELECT * FROM website_settings");
$stmt_web_settings->execute();
$web_settings = $stmt_web_settings->fetchAll();

$restaurant_name = "";
$restaurant_email = "";
$restaurant_address = "";
$restaurant_phonenumber = "";

foreach ($web_settings as $option) {
    if ($option['option_name'] == 'restaurant_name') {
        $restaurant_name = $option['option_value'];
    } elseif ($option['option_name'] == 'restaurant_email') {
        $restaurant_email = $option['option_value'];
    } elseif ($option['option_name'] == 'restaurant_phonenumber') {
        $restaurant_phonenumber = $option['option_value'];
    } elseif ($option['option_name'] == 'restaurant_address') {
        $restaurant_address = $option['option_value'];
    }
}

?>
<style>
    .star-rating {
        font-size: 30px;
        line-height: 1;
        display: inline-block;
        unicode-bidi: bidi-override;
        direction: ltr;
        /* Ensure left-to-right direction */
    }

    .star-rating .star {
        color: #ccc;
        cursor: pointer;
        display: inline-block;
        margin-right: 5px;
        transition: all 0.2s;
        position: relative;
    }

    .star-rating .star:hover,
    .star-rating .star.active {
        color: transparent;
    }

    .star-rating .star:hover:before,
    .star-rating .star.active:before {
        color: #ffc107;
        content: "★";
        position: absolute;
        left: 0;
    }

    /* Highlight stars to the right of hovered star */
    .star-rating .star:hover~.star {
        color: #ccc;
        /* Keep stars to the right as empty */
    }

    .star-rating .star:hover~.star:before {
        content: none;
        /* Remove filled stars to the right */
    }
</style>
<!-- HOME SECTION -->

<section class="home-section" id="home">
    <div class="container">
        <div class="row" style="flex-wrap: nowrap;">
            <div class="col-md-6 home-left-section">
                <div style="padding: 100px 0px; color: white;">
                    <h1>
                        ECO BOTANIC CAFE.
                    </h1>
                    <h2>
                        MAKE YOU HAPPY EVERYDAY
                    </h2>
                    <hr>
                    <p>
                        FUSION RESTAURANT WITH WIDE VARIETY OF LOCAL AND WESTERN FOOD
                    </p>
                    <div style="display: flex;">
                        <a href="order_food.php" target="_blank" class="bttn_style_2"
                            style="margin-right: 10px; display: flex;justify-content: center;align-items: center;">
                            ORDER NOW
                            <i class="fas fa-angle-right"></i>
                        </a>
                        <a href="#menu" class="bttn_style_2"
                            style="display: flex;justify-content: center;align-items: center;">
                            VIEW MENU
                            <i class="fas fa-angle-right"></i>
                        </a>
                    </div>
                </div>
            </div>

        </div>
    </div>
</section>


<!-- OUR menu SECTION -->

<section class="our_menu" id="menu">
    <div class="container">
        <h2 style="text-align: center;margin-bottom: 30px">DISCOVER OUR MENU</h2>
        <div class="menu_tabs">
            <div class="menu_tabs_picker">
                <ul style="text-align: center;margin-bottom: 70px">
                    <?php

                    $stmt = $con->prepare("Select * from menu_categories Where DELETED = 0");
                    $stmt->execute();
                    $rows = $stmt->fetchAll();
                    $count = $stmt->rowCount();

                    $x = 0;

                    foreach ($rows as $row) {
                        if ($x == 0) {
                            echo "<li class = 'menu_category_name tab_category_links active_category' onclick=showCategoryMenu(event,'" . str_replace(' ', '', $row['category_name']) . "')>";
                            echo $row['category_name'];
                            echo "</li>";

                        } else {
                            echo "<li class = 'menu_category_name tab_category_links' onclick=showCategoryMenu(event,'" . str_replace(' ', '', $row['category_name']) . "')>";
                            echo $row['category_name'];
                            echo "</li>";
                        }

                        $x++;

                    }
                    ?>
                </ul>
            </div>

            <div class="menu_tab">
                <?php

                $stmt = $con->prepare("Select * from menu_categories Where DELETED = 0");
                $stmt->execute();
                $rows = $stmt->fetchAll();
                $count = $stmt->rowCount();

                $i = 0;

                foreach ($rows as $row) {

                    if ($i == 0) {

                        echo '<div class="menu_item  tab_category_content" id="' . str_replace(' ', '', $row['category_name']) . '" style=display:block>';

                        $stmt_menu = $con->prepare("Select * from menu where category_id = ? AND DELETED = 0");
                        $stmt_menu->execute(array($row['category_id']));
                        $rows_menu = $stmt_menu->fetchAll();

                        if ($stmt_menu->rowCount() == 0) {
                            echo "<div style='margin:auto'>No Available menu for this category!</div>";
                        }

                        echo "<div class='row'>";
                        foreach ($rows_menu as $menu) {
                            ?>

                            <div class="col-md-4 col-lg-3 menu-column">
                                <div class="thumbnail" style="cursor:pointer">
                                    <?php $source = "admin/Uploads/images/" . $menu['menu_image']; ?>

                                    <div class="menu-image">
                                        <div class="image-preview">
                                            <div style="background-image: url('<?php echo $source; ?>');"></div>
                                        </div>
                                    </div>

                                    <div class="caption">
                                        <h5>
                                            <?php echo $menu['menu_name']; ?>
                                        </h5>
                                        <p>
                                            <?php echo $menu['menu_description']; ?>
                                        </p>
                                        <span class="menu_price">
                                            <?php echo "$" . $menu['menu_price']; ?>
                                        </span>
                                    </div>
                                </div>
                            </div>

                            <?php
                        }
                        echo "</div>";

                        echo '</div>';

                    } else {

                        echo '<div class="menu_categories  tab_category_content" id="' . str_replace(' ', '', $row['category_name']) . '">';

                        $stmt_menu = $con->prepare("Select * from menu where category_id = ? and DELETED = 0");
                        $stmt_menu->execute(array($row['category_id']));
                        $rows_menu = $stmt_menu->fetchAll();

                        if ($stmt_menu->rowCount() == 0) {
                            echo "<div class = 'no_menu_div'>No Available menu for this category!</div>";
                        }

                        echo "<div class='row'>";
                        foreach ($rows_menu as $menu) {
                            ?>

                            <div class="col-md-4 col-lg-3 menu-column">
                                <div class="thumbnail" style="cursor:pointer">
                                    <?php $source = "admin/Uploads/images/" . $menu['menu_image']; ?>
                                    <div class="menu-image">
                                        <div class="image-preview">
                                            <div style="background-image: url('<?php echo $source; ?>');"></div>
                                        </div>
                                    </div>
                                    <div class="caption">
                                        <h5>
                                            <?php echo $menu['menu_name']; ?>
                                        </h5>
                                        <p>
                                            <?php echo $menu['menu_description']; ?>
                                        </p>
                                        <span class="menu_price">
                                            <?php echo "$" . $menu['menu_price']; ?>
                                        </span>
                                    </div>
                                </div>
                            </div>

                            <?php
                        }
                        echo "</div>";

                        echo '</div>';

                    }

                    $i++;

                }

                echo "</div>";

                ?>
            </div>
        </div>
    </div>
</section>
<!--FEEDBACK SECTION-->
<section class="contact-section" id="contact">
    <div class="container">
        <div class="row">
            <!-- Left column (keep your existing content) -->
            <div class="col-lg-6 sm-padding">
                <div class="contact-info">
                    <h2>
                        Get in touch with us &
                        <br>send us message today!
                    </h2>
                    <p>
                        Saasbiz is a different kind of architecture practice. Founded by LoganCee in 1991, we’re
                        an
                        employee-owned firm pursuing a democratic design process that values everyone’s input.
                    </p>
                    <h3>
                        <?php echo $restaurant_address; ?>
                    </h3>
                    <h4>
                        <span>Email:</span>
                        <?php echo $restaurant_email; ?>
                        <br>
                        <span>Phone:</span>
                        <?php echo $restaurant_phonenumber; ?>
                    </h4>
                </div>
            </div>
            <div class="col-lg-6 sm-padding">
                <div class="contact-form">
                    <div id="contact_ajax_form" class="contactForm">
                        <div class="form-group colum-row row">
                            <div class="col-sm-6">
                                <input type="text" id="contact_name" name="name" class="form-control"
                                    placeholder="Name">
                                <div class="invalid-feedback" id="invalid-name"></div>
                            </div>
                            <div class="col-sm-6">
                                <input type="email" id="contact_email" name="email" class="form-control"
                                    placeholder="Email">
                                <div class="invalid-feedback" id="invalid-email"></div>
                            </div>
                        </div>

                        <!-- Star Rating -->
                        <div class="form-group row">
                            <div class="col-md-12">
                                <label>Your Rating</label>
                                <div class="star-rating">
                                    <span class="star" data-value="1">☆</span>
                                    <span class="star" data-value="2">☆</span>
                                    <span class="star" data-value="3">☆</span>
                                    <span class="star" data-value="4">☆</span>
                                    <span class="star" data-value="5">☆</span>
                                    <input type="hidden" name="rating" id="rating-value">
                                </div>
                                <div class="invalid-feedback" id="invalid-rating"></div>
                            </div>
                        </div>

                        <div class="form-group row">
                            <div class="col-md-12">
                                <textarea id="contact_message" name="message" cols="30" rows="5"
                                    class="form-control message" placeholder="Message"></textarea>
                                <div class="invalid-feedback" id="invalid-message"></div>
                            </div>
                        </div>

                        <div class="form-group row">
                            <div class="col-md-12">
                                <button id="contact_send" class="bttn_style_2">Send Message</button>
                            </div>
                        </div>

                        <div id="sending_load" style="display: none;">Sending...</div>
                        <div id="contact_status_message"></div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<!-- WIDGET SECTION / FOOTER -->

<section class="widget_section" style="background-color: #222227;padding: 100px 0;">
    <div class="container">
        <div class="row">
            <div class="col-lg-3 col-md-6">
                <div class="footer_widget">
                    <img src="Design/images/restaurant-logo.png" alt="Restaurant Logo"
                        style="width: 150px;margin-bottom: 20px;">
                    <p>
                        Our Restaurnt is one of the bests, provide tasty menu and Dishes.
                    </p>

                </div>
            </div>
            <div class="col-lg-3 col-md-6">
                <div class="footer_widget">
                    <h3>Address</h3>
                    <p>
                        22, Level 3, Eco Gallery, Eco Botanic
                    </p>
                    <p>
                        ecobotanic.cafe@gmail.com
                        <br>
                        018-9986545
                    </p>
                </div>
            </div>
            <div class="col-lg-3 col-md-6">
                <div class="footer_widget">
                    <h3>
                        Opening Hours
                    </h3>
                    <ul class="opening_time">
                        <li>Monday - Friday 10:00am - 9:00pm</li>
                    </ul>
                </div>
            </div>

        </div>
    </div>
</section>

<!-- FOOTER BOTTOM  -->

<?php include "Includes/templates/footer.php"; ?>

<script>
    $(document).ready(function () {

        $('.star-rating .star').hover(
            function () {

                const currentValue = $(this).data('value');
                $('.star-rating .star').each(function () {
                    if ($(this).data('value') <= currentValue) {
                        $(this).addClass('hover');
                    } else {
                        $(this).removeClass('hover');
                    }
                });
            },
            function () {

                $('.star-rating .star').removeClass('hover');
            }
        ).click(function () {

            const rating = $(this).data('value');
            $('#rating-value').val(rating);


            $('.star-rating .star').removeClass('active');
            $('.star-rating .star').each(function () {
                if ($(this).data('value') <= rating) {
                    $(this).addClass('active');
                }
            });

            $('#invalid-rating').hide();
        });

        // Form Submission
        $('#contact_send').click(function () {
            // Reset validation
            $('.invalid-feedback').hide();
            $('#contact_status_message').hide().removeClass('success-message error-message');

            // Get values
            const contact_name = $('#contact_name').val().trim();
            const contact_email = $('#contact_email').val().trim();
            const contact_message = $('#contact_message').val().trim();
            const rating = $('#rating-value').val();

            // Validate
            let valid = true;

            if (contact_name.length < 2) {
                $('#invalid-name').text(contact_name ? 'Name is too short' : 'Name is required').show();
                valid = false;
            }

            if (!contact_email) {
                $('#invalid-email').text('Email is required').show();
                valid = false;
            } else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(contact_email)) {
                $('#invalid-email').text('Invalid email format').show();
                valid = false;
            }

            if (contact_message.length < 10) {
                $('#invalid-message').text(contact_message ? 'Message is too short' : 'Message is required').show();
                valid = false;
            }

            if (!rating) {
                $('#invalid-rating').text('Please select a rating').show();
                valid = false;
            }

            if (valid) {
                $('#sending_load').show();

                $.ajax({
                    url: "Includes/php-files-ajax/contact.php",
                    type: "POST",
                    dataType: 'json',
                    data: {
                        contact_name: contact_name,
                        contact_email: contact_email,
                        contact_message: contact_message,
                        rating: rating
                    },
                    success: function (response) {
                        if (response.status === 'success') {
                            // Show success message
                            $('#contact_status_message')
                                .addClass('success-message')
                                .html(response.message)
                                .show();

                            // Reset form
                            $('#contact_name, #contact_email, #contact_message').val('');
                            $('#rating-value').val('');
                            $('.star-rating .star').removeClass('active');
                        } else {
                            // Show error message
                            $('#contact_status_message')
                                .addClass('error-message')
                                .html(response.message)
                                .show();
                        }
                    },
                    error: function (xhr, status, error) {
                        $('#contact_status_message')
                            .addClass('error-message')
                            .html('An error occurred. Please try again later.')
                            .show();
                    },
                    complete: function () {
                        $('#sending_load').hide();
                    }
                });
            }
        });
    });
</script>